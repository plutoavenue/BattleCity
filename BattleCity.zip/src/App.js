import React, { Component } from 'react'
import Game from './components/state/Game'
import './App.css'

class App extends Component {

    render() {
        return (
                        <Game  />
        );
    }
}
export default App;